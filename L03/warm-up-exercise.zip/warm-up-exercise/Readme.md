Mit den Grundlagen zu HTML sollten Sie eine bestehende HTML Struktur in seinen grundlegenden Elementen verstehen können.



Dazu eine kleine Übung:

Hier finden Sie ein (gekürztes) Beispiel aus Wikipedia (ohne Styles).

1. Das Bild wird nicht angezeigt. Können Sie das korrigieren?
2. Der interne Verweis unter dem Bild funktioniert nicht ("Visual Storytelling by Suhani Gowan"). Bei Klick auf die "1" soll zur Quelle gesprungen werden. Können Sie das korrigieren?
3. In der HTML Datei finden Sie folgende Info "Cached time: 20211015174709". Was könnte damit gemeint sein?

