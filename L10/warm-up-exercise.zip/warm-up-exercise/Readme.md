Mit diesen kleinen Übungen sollen wieder die Inhalte zu Variablendeklaration, Objekte und Algorithmen der aktuellen Lektion wiederholt werden:

### Übung A:
Bilden Sie drei Personen dieses Kurses durch Objekte ab. Erstellen Sie dazu ein Interface, dass alle relevanten Eigenschaften dieser Personen beinhaltet.

### Übung B:
Die Namen dieser drei Personen sollen nacheinander in der Konsole ausgegeben werden. Entwickeln Sie eine Lösung, die flexibel ist und einfach skaliert, um auch 100 oder 1000 Personen ausgeben lassen zu können.

### Übung A:
Ermitteln Sie aus einer beliebigen Anzahl numberischer Werte deren Summe und geben Sie diese in der Konsole aus.
